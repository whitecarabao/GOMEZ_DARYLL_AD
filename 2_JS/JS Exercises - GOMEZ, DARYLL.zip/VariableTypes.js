//Daryll's VariableTypes Exercise

//some variables
var ohLookAnArray = [1, 2, 3, 4, 5, 6];
var ahYesAnObject = {
    studenID : "202020202",
    firstName : "JUAN",
    lastName : "DELA CRUZ"
};
var someKrazyString ="WOW DAS KRAZYYYYYY SHEESH";
var nullVar = null;
var aNumberVar = 10101010;
var aBooleanVar = true;

//some code
console.log(ohLookAnArray);
console.log("The variable " + ohLookAnArray + " is of type " + typeof ohLookAnArray + "\n");

console.log(ahYesAnObject);
console.log("The variable " + ahYesAnObject + " is of type " + typeof ahYesAnObject + "\n");

console.log(someKrazyString);
console.log("The variable " + someKrazyString + " is of type " + typeof someKrazyString + "\n");

console.log(nullVar);
console.log("The variable " + nullVar + " is of type " + typeof nullVar + "\n");

console.log(aNumberVar);
console.log("The variable " + aNumberVar + " is of type " + typeof aNumberVar + "\n");

console.log(null);
console.log("The variable " + null + " is of type " + typeof null + "\n");

console.log(aBooleanVar);
console.log("The variable " + aBooleanVar + " is of type " + typeof aBooleanVar + "\n");

console.log(undefined);
console.log("The variable " + undefined + " is of type " + typeof undefined + "\n");

